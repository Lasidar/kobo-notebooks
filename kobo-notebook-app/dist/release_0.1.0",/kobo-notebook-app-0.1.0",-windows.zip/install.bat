
@echo off
echo Installing Kobo Notebook App...
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo Python is not installed or not in PATH.
    echo Please install Python 3.8 or higher from https://python.org
    pause
    exit /b 1
)

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt

REM Create desktop shortcut
echo Creating desktop shortcut...
python -c "
import os
from pathlib import Path
import winshell
from win32com.client import Dispatch

desktop = winshell.desktop()
shortcut_path = os.path.join(desktop, 'Kobo Notebook App.lnk')
target = os.path.join(os.getcwd(), 'src', 'desktop_app', 'main.py')

shell = Dispatch('WScript.Shell')
shortcut = shell.CreateShortCut(shortcut_path)
shortcut.Targetpath = 'python'
shortcut.Arguments = target
shortcut.WorkingDirectory = os.getcwd()
shortcut.IconLocation = target
shortcut.save()
"

echo Installation complete!
echo You can now run the application from the desktop shortcut.
pause
