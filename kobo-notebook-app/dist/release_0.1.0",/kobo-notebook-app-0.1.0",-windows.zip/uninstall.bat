
@echo off
echo Uninstalling Kobo Notebook App...
echo.

REM Remove desktop shortcut
echo Removing desktop shortcut...
del "%USERPROFILE%\Desktop\Kobo Notebook App.lnk" 2>nul

REM Remove application files
echo Removing application files...
rd /s /q "%~dp0" 2>nul

echo Uninstallation complete!
pause
