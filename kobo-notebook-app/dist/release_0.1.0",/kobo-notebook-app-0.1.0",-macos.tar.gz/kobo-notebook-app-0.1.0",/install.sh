#!/bin/bash

echo "Installing Kobo Notebook App..."
echo

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt

# Create Applications directory entry
echo "Creating application entry..."
app_dir="$HOME/Applications/Kobo Notebook App"
mkdir -p "$app_dir"

# Copy application files
cp -r . "$app_dir/"

# Create launcher script
launcher="$app_dir/launch.sh"
cat > "$launcher" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
python3 src/desktop_app/main.py
EOF

chmod +x "$launcher"

# Create Applications directory entry
app_entry="$app_dir/Kobo Notebook App.app"
mkdir -p "$app_entry/Contents/MacOS"
mkdir -p "$app_entry/Contents/Resources"

# Create Info.plist
cat > "$app_entry/Contents/Info.plist" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>launch.sh</string>
    <key>CFBundleIdentifier</key>
    <string>com.kobo-notebook-app</string>
    <key>CFBundleName</key>
    <string>Kobo Notebook App</string>
    <key>CFBundleVersion</key>
    <string>1.0.0</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0.0</string>
</dict>
</plist>
EOF

# Create symbolic link to launcher
ln -sf "../launch.sh" "$app_entry/Contents/MacOS/launch.sh"

echo "Installation complete!"
echo "You can find the application in your Applications folder."
