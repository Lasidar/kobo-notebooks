#!/bin/bash

echo "Uninstalling Kobo Notebook App..."
echo

# Remove desktop entry
desktop_dir="$HOME/.local/share/applications"
rm -f "$desktop_dir/kobo-notebook-app.desktop"

# Update desktop database
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$desktop_dir"
fi

# Remove application files
echo "Removing application files..."
rm -rf "$(dirname "$0")"

echo "Uninstallation complete!"
