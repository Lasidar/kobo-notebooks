#!/bin/bash

echo "Installing Kobo Notebook App..."
echo

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt

# Create desktop entry
echo "Creating desktop entry..."
desktop_dir="$HOME/.local/share/applications"
mkdir -p "$desktop_dir"
cp kobo-notebook-app.desktop "$desktop_dir/"

# Make desktop entry executable
chmod +x "$desktop_dir/kobo-notebook-app.desktop"

# Update desktop database
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$desktop_dir"
fi

echo "Installation complete!"
echo "You can find the application in your applications menu."
